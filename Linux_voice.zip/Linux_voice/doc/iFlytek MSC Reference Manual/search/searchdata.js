var indexSectionsWithContent =
{
  0: "abcdefgijklmpqstuz",
  1: "adfjmqs",
  2: "bcegimpqstu",
  3: "abciklsz"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "全部",
  1: "文件",
  2: "函数",
  3: "变量"
};

